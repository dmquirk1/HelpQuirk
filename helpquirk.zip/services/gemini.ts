
import { GoogleGenAI, Type } from "@google/genai";

// Initialize AI (SDK remains available for real calls)
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "fallback_key" });

/**
 * MOCK DATA REPOSITORY
 * Provides high-quality realistic data for "Free/Mock" mode
 */
const MOCK_DATA = {
  dna: {
    season: "Warm Autumn",
    palette: ["#f97316", "#D2691E", "#556B2F", "#DAA520", "#B45309"],
    hairTip: "Golden honey highlights would enhance your professional warmth and compliment your skin's golden undertones.",
    makeupAdvice: "Opt for warm peach blushes and terra-cotta lip tones to make your features pop."
  },
  roadmap: (niche: string) => ({
    businessName: `${niche || 'Boutique'} Agency`,
    steps: [
      { title: "Niche Validation", description: "Identify your unique 'Quirk' factor and target high-value clients in the local market." },
      { title: "Portfolio Development", description: "Create 5 distinct case studies or 'Looks' using HelpQuirk's Style Lab to showcase your vision." },
      { title: "Team Assembly", description: "Hire specialized 'Helpers' from the Quirk Marketplace (Stylists, Coordinators, Decorators)." },
      { title: "Social Launch", description: "Execute a 14-day vertical video campaign on HelpQuirk to build authority and drive leads." },
      { title: "Scale & Automate", description: "Implement AI routine management for clients to ensure long-term retention and recurring revenue." }
    ],
    skillsToHire: ["Visual Merchandiser", "Social Media Stylist", "Event Decorator"]
  }),
  skincare: [
    { title: "pH Balanced Cleanser", time: "8:00 AM", category: "Skin" },
    { title: "Vitamin C + Ferulic Acid", time: "8:15 AM", category: "Skin" },
    { title: "Ceramide Barrier Cream", time: "8:30 AM", category: "Skin" },
    { title: "SPF 50+ Invisible Fluid", time: "8:45 AM", category: "Skin" },
    { title: "Niacinamide Overnight Mask", time: "10:00 PM", category: "Skin" }
  ],
  outfits: {
    powerful: "https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?auto=format&fit=crop&q=80&w=1000",
    relaxed: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&q=80&w=1000",
    romantic: "https://images.unsplash.com/photo-1518764876364-284206c09655?auto=format&fit=crop&q=80&w=1000",
    creative: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&q=80&w=1000",
    default: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=1000"
  }
};

const simulateDelay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const analyzeColorDNA = async (imageBase64: string): Promise<any> => {
  try {
    // Attempt real API call
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{
        parts: [
          { inlineData: { data: imageBase64.split(',')[1], mimeType: 'image/jpeg' } },
          { text: "Analyze skin tone and palette. Return JSON." }
        ]
      }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            season: { type: Type.STRING },
            palette: { type: Type.ARRAY, items: { type: Type.STRING } },
            hairTip: { type: Type.STRING },
            makeupAdvice: { type: Type.STRING }
          },
          required: ["season", "palette", "hairTip", "makeupAdvice"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    // Fallback to Mock
    await simulateDelay(1500);
    return MOCK_DATA.dna;
  }
};

export const getClimateRoutineTips = async (weather: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Weather is ${weather}. Give 3 tips.`,
    });
    return response.text;
  } catch (error) {
    return "1. Wear SPF 50+ as UV index is peaking.\n2. Use a lightweight water-based moisturizer.\n3. Keep hydrated to maintain skin elasticity.";
  }
};

export const generateOutfit = async (prompt: string, base64Image?: string): Promise<string | null> => {
  try {
    const parts: any[] = [{ text: `Aesthetic outfit for: ${prompt}` }];
    if (base64Image) parts.unshift({ inlineData: { data: base64Image.split(',')[1], mimeType: 'image/jpeg' } });

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts },
      config: { imageConfig: { aspectRatio: "3:4" } }
    });

    for (const candidate of response.candidates || []) {
      for (const part of candidate.content.parts) {
        if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    // Fallback to high-quality Unsplash image based on prompt context
    await simulateDelay(2000);
    const p = prompt.toLowerCase();
    if (p.includes('powerful')) return MOCK_DATA.outfits.powerful;
    if (p.includes('relaxed')) return MOCK_DATA.outfits.relaxed;
    if (p.includes('romantic')) return MOCK_DATA.outfits.romantic;
    if (p.includes('creative')) return MOCK_DATA.outfits.creative;
    return MOCK_DATA.outfits.default;
  }
};

export const generateBusinessRoadmap = async (niche: string): Promise<any> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Roadmap for ${niche} business. JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            businessName: { type: Type.STRING },
            steps: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, description: { type: Type.STRING } } } },
            skillsToHire: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    await simulateDelay(1800);
    return MOCK_DATA.roadmap(niche);
  }
};

export const getSkinCareAdvice = async (skinType: string, concerns: string[]): Promise<any[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Routine for ${skinType} with ${concerns.join(', ')}. JSON array.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              time: { type: Type.STRING },
              category: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    await simulateDelay(1200);
    return MOCK_DATA.skincare;
  }
};
