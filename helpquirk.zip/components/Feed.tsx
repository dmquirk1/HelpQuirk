import React, { useState } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  MoreVertical, 
  Trophy,
  ShoppingBag,
  BadgeCheck,
  Tag,
  Sparkles,
  ArrowRight,
  X,
  UserPlus,
  Play,
  LayoutGrid,
  Shirt,
  Sparkles as SkincareIcon,
  Briefcase
} from 'lucide-react';
import { MOCK_POSTS } from '../constants';

const CATEGORIES = [
  { id: 'all', label: 'All', icon: LayoutGrid },
  { id: 'outfit', label: 'Outfits', icon: Shirt },
  { id: 'skincare', label: 'Looksmax', icon: SkincareIcon },
  { id: 'business', label: 'Biz Gigs', icon: Briefcase },
];

const VideoModal: React.FC<{ post: any; onClose: () => void }> = ({ post, onClose }) => {
  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex items-center justify-center animate-in fade-in duration-300 p-0 md:p-10">
      <div className="relative w-full max-w-[900px] h-full md:h-auto md:aspect-[16/9] bg-white md:rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col md:flex-row">
        {/* Main Video Area */}
        <div className="relative flex-[1.2] bg-black flex items-center justify-center">
          <img src={post.videoUrl} alt="Post Content" className="w-full h-full object-cover opacity-80" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
          
          <button onClick={onClose} className="absolute top-6 left-6 p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-colors z-50">
            <X className="w-6 h-6" />
          </button>
          
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white/10 p-8 rounded-full backdrop-blur-xl border border-white/20">
              <Play className="w-12 h-12 text-white fill-white" />
            </div>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="w-full md:w-96 bg-white p-8 flex flex-col justify-between overflow-y-auto">
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <img src={post.avatar} className="w-12 h-12 rounded-full border-2 border-orange-500" alt={post.user} />
                <div>
                  <h4 className="font-black text-slate-900 text-base">{post.user}</h4>
                  <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">HelpQuirk Partner</p>
                </div>
              </div>
              <button className="bg-orange-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-500 shadow-md">
                Follow
              </button>
            </div>

            <div>
              <p className="text-slate-600 font-medium leading-relaxed">{post.description}</p>
            </div>
            
            {post.isProduct && (
              <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 space-y-4 shadow-inner">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-orange-600" />
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Shop Item</span>
                  </div>
                  <span className="text-xl font-black text-slate-900">${post.price}</span>
                </div>
                <button className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-slate-800 transition-all flex items-center justify-center gap-3">
                  Check Availability
                </button>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center pt-8 border-t border-slate-100 mt-8">
            <div className="flex gap-8">
              <div className="flex flex-col items-center gap-1 group cursor-pointer">
                <Heart className="w-6 h-6 text-slate-400 group-hover:text-red-500 transition-colors" />
                <span className="text-[10px] font-black text-slate-400">{post.likes}</span>
              </div>
              <div className="flex flex-col items-center gap-1 group cursor-pointer">
                <MessageCircle className="w-6 h-6 text-slate-400 group-hover:text-orange-500 transition-colors" />
                <span className="text-[10px] font-black text-slate-400">{post.comments}</span>
              </div>
            </div>
            <button className="p-3 bg-slate-50 rounded-full text-slate-400 hover:text-slate-900 transition-colors">
              <Share2 className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Feed: React.FC = () => {
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [selectedVideo, setSelectedVideo] = useState<any | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');

  const handleLike = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newLikedPosts = new Set(likedPosts);
    if (newLikedPosts.has(id)) newLikedPosts.delete(id);
    else newLikedPosts.add(id);
    setLikedPosts(newLikedPosts);
  };

  const filteredPosts = activeCategory === 'all' 
    ? MOCK_POSTS 
    : MOCK_POSTS.filter(post => post.category === activeCategory);

  return (
    <div className="flex flex-col items-center gap-8 py-8 w-full px-4 md:px-0">
      {selectedVideo && <VideoModal post={selectedVideo} onClose={() => setSelectedVideo(null)} />}

      {/* Category Filter Bar - Sticky at top of content area */}
      <div className="w-full max-w-md sticky top-0 z-30 bg-slate-50/80 backdrop-blur-md py-4">
        <div className="flex gap-3 overflow-x-auto no-scrollbar justify-center">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border shrink-0 ${
                activeCategory === cat.id
                  ? 'bg-orange-600 border-orange-500 text-white shadow-xl shadow-orange-600/20 scale-105'
                  : 'bg-white border-slate-200 text-slate-500 hover:border-orange-300 hover:text-orange-600'
              }`}
            >
              <cat.icon className="w-4 h-4" />
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Feed Content */}
      <div className="grid grid-cols-1 gap-10 w-full max-w-md pb-20">
        {filteredPosts.length > 0 ? (
          filteredPosts.map((post: any) => {
            const isLiked = likedPosts.has(post.id);
            
            return (
              <div 
                key={post.id} 
                onClick={() => setSelectedVideo(post)}
                className="relative bg-white rounded-[2.5rem] overflow-hidden w-full shadow-2xl border border-slate-200 group/card cursor-pointer animate-in fade-in slide-in-from-bottom-6 duration-700"
              >
                {/* Header Info */}
                <div className="absolute top-6 left-6 right-6 flex justify-between items-start z-10 pointer-events-none">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-3 bg-white/90 backdrop-blur-md p-1.5 rounded-full pr-4 border border-slate-200 pointer-events-auto shadow-sm">
                      <img src={post.avatar} alt={post.user} className="w-8 h-8 rounded-full border-2 border-orange-500" />
                      <span className="font-black text-xs text-slate-900 flex items-center gap-1">
                        {post.user}
                        {post.isSeller && <BadgeCheck className="w-3.5 h-3.5 text-sky-500 fill-sky-500" />}
                      </span>
                    </div>
                  </div>
                  {post.quirkScore && (
                    <div className="bg-orange-600 p-2 px-4 rounded-full border border-orange-400/30 shadow-lg pointer-events-auto flex items-center gap-2">
                       <Trophy className="w-3 h-3 text-white" />
                       <span className="text-[10px] font-black text-white uppercase tracking-tighter">QS: {post.quirkScore}</span>
                    </div>
                  )}
                </div>
                
                <div className="relative w-full aspect-[4/5] overflow-hidden">
                  <img 
                    src={post.videoUrl} 
                    alt="Content" 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover/card:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/60 opacity-60" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/card:opacity-100 transition-all duration-500 transform scale-75 group-hover/card:scale-100">
                     <div className="bg-white/20 p-6 rounded-full backdrop-blur-xl border border-white/20">
                        <Play className="w-10 h-10 text-white fill-white" />
                     </div>
                  </div>
                </div>

                {/* Footer Info */}
                <div className="p-8 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-6">
                      <button onClick={(e) => handleLike(e, post.id)} className="flex items-center gap-2 group outline-none">
                        <Heart className={`w-6 h-6 transition-all ${isLiked ? 'text-red-500 fill-red-500 scale-125' : 'text-slate-400 hover:text-red-500'}`} />
                        <span className="text-xs font-black text-slate-400">{post.likes + (isLiked ? 1 : 0)}</span>
                      </button>
                      <button className="flex items-center gap-2 group">
                        <MessageCircle className="w-6 h-6 text-slate-400 hover:text-orange-500 transition-colors" />
                        <span className="text-xs font-black text-slate-400">{post.comments}</span>
                      </button>
                    </div>
                    <button onClick={(e) => e.stopPropagation()} className="p-2 hover:bg-slate-50 rounded-full text-slate-400 hover:text-slate-900 transition-colors">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <div className="space-y-1">
                    <p className="text-sm text-slate-800 font-medium leading-relaxed line-clamp-2">
                      <span className="font-black mr-2">@{post.user}</span>
                      {post.description}
                    </p>
                    <div className="flex flex-wrap gap-2 pt-2">
                       <span className="text-[10px] font-black text-orange-600 bg-orange-50 px-3 py-1 rounded-full border border-orange-100 uppercase tracking-widest">
                         #{post.category}
                       </span>
                    </div>
                  </div>

                  {post.isProduct && (
                    <button className="w-full mt-4 bg-slate-900 hover:bg-slate-800 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-3 transition-all active:scale-95 shadow-xl shadow-slate-900/10">
                      <ShoppingBag className="w-4 h-4" />
                      View Item Details • ${post.price}
                    </button>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-slate-300">
            <LayoutGrid className="w-20 h-20 mb-6 opacity-20" />
            <p className="text-xl font-black text-slate-900">No Content Found</p>
            <p className="text-sm font-medium">Be the first to post in this category!</p>
            <button className="mt-8 bg-orange-600 text-white px-8 py-3 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-orange-500 shadow-lg shadow-orange-600/20 transition-all">
              Create First Look
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Feed;