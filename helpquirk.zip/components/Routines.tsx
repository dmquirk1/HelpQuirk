import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  Plus, 
  Zap, 
  CloudSun, 
  Flame, 
  History, 
  Calendar as CalendarIcon, 
  Wand2, 
  Loader2, 
  X, 
  Check, 
  Droplets 
} from 'lucide-react';
import { getClimateRoutineTips, getSkinCareAdvice } from '../services/gemini';

const INITIAL_ROUTINES = [
  { id: '1', title: 'Gentle Cleanser', time: '8:00 AM', category: 'Skin', completed: true },
  { id: '2', title: 'Vitamin C Serum', time: '8:15 AM', category: 'Skin', completed: false },
  { id: '3', title: 'Cold Shower & Moisturize', time: '8:30 AM', category: 'Body', completed: false },
  { id: '4', title: 'Scalp Massage', time: '9:00 PM', category: 'Hair', completed: false },
  { id: '5', title: 'Retinol Application', time: '10:00 PM', category: 'Skin', completed: false },
];

const SKIN_TYPES = ['Oily', 'Dry', 'Combination', 'Sensitive', 'Normal'];
const SKIN_CONCERNS = ['Acne', 'Fine Lines', 'Dark Spots', 'Redness', 'Dullness', 'Pores', 'Texture'];

const Routines: React.FC = () => {
  const [routines, setRoutines] = useState(INITIAL_ROUTINES);
  const [streak, setStreak] = useState(12);
  const [climateTips, setClimateTips] = useState<string[]>([]);
  const [loadingTips, setLoadingTips] = useState(true);
  const [showVault, setShowVault] = useState(false);
  const [showBuilder, setShowBuilder] = useState(false);

  // Builder State
  const [selectedSkinType, setSelectedSkinType] = useState<string | null>(null);
  const [selectedConcerns, setSelectedConcerns] = useState<string[]>([]);
  const [building, setBuilding] = useState(false);
  const [suggestedRoutine, setSuggestedRoutine] = useState<any[] | null>(null);

  useEffect(() => {
    const fetchTips = async () => {
      setLoadingTips(true);
      const tips = await getClimateRoutineTips("Sunny, 28°C, High Humidity");
      setClimateTips(tips.split('\n').filter(t => t.trim()));
      setLoadingTips(false);
    };
    fetchTips();
  }, []);

  const toggleRoutine = (id: string) => {
    setRoutines(prev => prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r));
  };

  const handleBuildRoutine = async () => {
    if (!selectedSkinType || selectedConcerns.length === 0) return;
    setBuilding(true);
    const result = await getSkinCareAdvice(selectedSkinType, selectedConcerns);
    setSuggestedRoutine(result);
    setBuilding(false);
  };

  const applySuggestedRoutine = () => {
    if (!suggestedRoutine) return;
    const newItems = suggestedRoutine.map((item, idx) => ({
      ...item,
      id: `ai-${Date.now()}-${idx}`,
      completed: false
    }));
    setRoutines(prev => [...newItems, ...prev]);
    setShowBuilder(false);
    setSuggestedRoutine(null);
    setSelectedConcerns([]);
    setSelectedSkinType(null);
  };

  const toggleConcern = (concern: string) => {
    setSelectedConcerns(prev => 
      prev.includes(concern) ? prev.filter(c => c !== concern) : [...prev, concern]
    );
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 space-y-8">
      {/* Header & Streak */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div>
          <h2 className="text-4xl font-black mb-1 text-slate-900">Daily Discipline</h2>
          <p className="text-slate-500 font-medium">Master your consistency, master your look.</p>
        </div>
        
        <div className="bg-orange-50 border border-orange-200 px-6 py-3 rounded-2xl flex items-center gap-3 shadow-sm">
          <div className="relative">
            <Flame className="w-8 h-8 text-orange-600 animate-pulse fill-orange-500/10" />
            <div className="absolute -top-1 -right-1 bg-orange-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full ring-2 ring-white">HOT</div>
          </div>
          <div>
            <p className="text-2xl font-black text-slate-900 leading-none">{streak}</p>
            <p className="text-[10px] text-orange-600 font-bold uppercase tracking-widest mt-1">Day Glow Streak</p>
          </div>
        </div>
      </div>

      {/* Main Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button 
          onClick={() => setShowBuilder(true)}
          className="bg-orange-600 border border-orange-500/30 p-6 rounded-[2rem] flex items-center gap-4 hover:bg-orange-500 transition-all group shadow-xl shadow-orange-600/10"
        >
          <div className="bg-white/20 p-4 rounded-2xl group-hover:rotate-12 transition-transform shadow-sm">
            <Wand2 className="w-6 h-6 text-white" />
          </div>
          <div className="text-left text-white">
            <p className="text-[10px] font-black text-white/80 uppercase tracking-widest">AI Laboratory</p>
            <h4 className="font-black">Routine Builder</h4>
          </div>
        </button>
        <button 
          onClick={() => setShowVault(true)}
          className="bg-white border border-slate-200 p-6 rounded-[2rem] flex items-center gap-4 hover:border-orange-500/50 transition-all group shadow-md"
        >
          <div className="bg-orange-50 p-4 rounded-2xl group-hover:scale-110 transition-transform">
            <History className="w-6 h-6 text-orange-600" />
          </div>
          <div className="text-left">
            <p className="text-[10px] font-black text-orange-600 uppercase tracking-widest">Progress Vault</p>
            <h4 className="font-black text-slate-900">Skin Analysis History</h4>
          </div>
        </button>
      </div>

      {/* AI Builder Modal */}
      {showBuilder && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] border border-slate-100 overflow-hidden shadow-2xl animate-in zoom-in duration-300">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-orange-50">
              <div className="flex items-center gap-3 text-orange-600">
                <Wand2 className="w-6 h-6" />
                <h3 className="text-2xl font-black text-slate-900">Personalized Science</h3>
              </div>
              <button onClick={() => setShowBuilder(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400"><X className="w-6 h-6" /></button>
            </div>
            
            <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
              {!suggestedRoutine ? (
                <>
                  <div className="space-y-4">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <Droplets className="w-4 h-4 text-orange-500" />
                      Step 1: Your Skin Type
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {SKIN_TYPES.map(type => (
                        <button
                          key={type}
                          onClick={() => setSelectedSkinType(type)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                            selectedSkinType === type 
                            ? 'bg-orange-600 border-orange-500 text-white shadow-md' 
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-900'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <Zap className="w-4 h-4 text-orange-500" />
                      Step 2: Key Concerns
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {SKIN_CONCERNS.map(concern => {
                        const active = selectedConcerns.includes(concern);
                        return (
                          <button
                            key={concern}
                            onClick={() => toggleConcern(concern)}
                            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                              active 
                              ? 'bg-amber-500 border-amber-400 text-white shadow-md' 
                              : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-900'
                            }`}
                          >
                            {active && <Check className="w-3 h-3 inline mr-1" />}
                            {concern}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button 
                    onClick={handleBuildRoutine}
                    disabled={building || !selectedSkinType || selectedConcerns.length === 0}
                    className="w-full py-4 bg-orange-600 disabled:opacity-50 text-white font-black rounded-2xl shadow-xl shadow-orange-600/20 active:scale-95 transition-all flex items-center justify-center gap-3 uppercase tracking-widest"
                  >
                    {building ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
                    {building ? 'Formulating...' : 'Build Custom Routine'}
                  </button>
                </>
              ) : (
                <div className="space-y-6 animate-in fade-in duration-500">
                  <div className="text-center">
                    <p className="text-orange-600 font-bold uppercase tracking-widest text-[10px]">AI Suggestions Ready</p>
                    <h4 className="text-xl font-black mt-1 text-slate-900">Your Science-Backed Routine</h4>
                  </div>
                  
                  <div className="space-y-3">
                    {suggestedRoutine.map((item, i) => (
                      <div key={i} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                         <div>
                           <p className="font-bold text-slate-900">{item.title}</p>
                           <p className="text-[10px] text-slate-500 uppercase font-black tracking-tighter mt-1">{item.time} • {item.category}</p>
                         </div>
                         <div className="w-8 h-8 rounded-full bg-orange-600/10 flex items-center justify-center">
                            <Check className="w-4 h-4 text-orange-600" />
                         </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-4">
                    <button 
                      onClick={() => setSuggestedRoutine(null)}
                      className="flex-1 py-4 border border-slate-200 text-slate-500 font-bold rounded-2xl hover:bg-slate-100 transition-all uppercase text-xs tracking-widest"
                    >
                      Restart
                    </button>
                    <button 
                      onClick={applySuggestedRoutine}
                      className="flex-[2] py-4 bg-orange-600 text-white font-black rounded-2xl shadow-xl shadow-orange-600/20 active:scale-95 transition-all uppercase text-xs tracking-widest"
                    >
                      Commit to Look
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Progress Vault Overlay */}
      {showVault && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-2xl rounded-[3rem] border border-slate-100 overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                 <h3 className="text-2xl font-black text-slate-900">Skin Time-lapse</h3>
                 <button onClick={() => setShowVault(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400"><X className="w-6 h-6 rotate-45" /></button>
              </div>
              <div className="p-8 space-y-8">
                 <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {[1, 2, 3, 4, 5, 6].map(i => (
                       <div key={i} className="aspect-square bg-slate-100 rounded-3xl border border-slate-200 relative group overflow-hidden shadow-sm">
                          <img src={`https://picsum.photos/seed/face${i}/200/200`} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                          <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-md px-2 py-1 rounded-lg text-[10px] font-black text-slate-900 shadow-sm">
                             Oct {10 + i}, 2024
                          </div>
                       </div>
                    ))}
                 </div>
                 <button className="w-full py-4 bg-orange-600 text-white font-black rounded-2xl shadow-xl shadow-orange-600/20 active:scale-95 transition-all uppercase tracking-widest">
                    Generate AI Progress Video
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* Climate-Sync Feature */}
      <div className="bg-white rounded-[2rem] p-6 border border-slate-200 relative overflow-hidden group shadow-md">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
          <CloudSun className="w-32 h-32 text-orange-600" />
        </div>
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 flex flex-col items-center min-w-[140px] shadow-inner">
            <CloudSun className="w-10 h-10 text-orange-500 mb-2" />
            <p className="text-xl font-black text-slate-900">28°C</p>
            <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest mt-1">Sunny • Miami</p>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-black flex items-center gap-2 mb-3 text-slate-900">
              <Zap className="w-4 h-4 text-orange-500" />
              Climate-Sync Protocol
            </h3>
            {loadingTips ? (
              <div className="space-y-2">
                <div className="h-4 bg-slate-100 rounded animate-pulse w-3/4" />
                <div className="h-4 bg-slate-100 rounded animate-pulse w-1/2" />
              </div>
            ) : (
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {climateTips.map((tip, i) => (
                  <li key={i} className="text-sm text-slate-600 font-medium flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-orange-600 rounded-full mt-1.5 shrink-0" />
                    {tip.replace(/^\d+\.\s*/, '')}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-lg">
            <div className="p-6 bg-slate-50 flex items-center justify-between border-b border-slate-200">
              <span className="font-black uppercase tracking-widest text-xs text-slate-500">Current Regimen</span>
              <span className="text-sm font-black text-orange-600 bg-orange-600/10 px-3 py-1 rounded-full">
                {routines.filter(r => r.completed).length}/{routines.length} DONE
              </span>
            </div>
            
            <div className="divide-y divide-slate-100">
              {routines.map((item) => (
                <div 
                  key={item.id} 
                  onClick={() => toggleRoutine(item.id)}
                  className="p-5 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-all group"
                >
                  <div className="flex items-center gap-5">
                    <div className={`transition-all duration-300 ${item.completed ? 'text-orange-600 scale-110' : 'text-slate-300 group-hover:text-slate-400'}`}>
                      {item.completed ? <CheckCircle2 className="w-7 h-7" /> : <Circle className="w-7 h-7" />}
                    </div>
                    <div>
                      <h4 className={`font-black text-lg transition-all ${item.completed ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
                        {item.title}
                      </h4>
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                        <span className="bg-slate-100 px-2.5 py-1 rounded-lg text-slate-500 uppercase font-black text-[9px] tracking-widest border border-slate-200">
                          {item.category}
                        </span>
                        <div className="flex items-center gap-1 font-bold">
                          <Clock className="w-3.5 h-3.5 text-orange-500" />
                          {item.time}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full p-4 text-slate-400 hover:text-orange-600 text-sm font-black flex items-center justify-center gap-2 transition-colors border-t border-slate-100 uppercase tracking-widest">
              <Plus className="w-4 h-4" /> Add Protocol Step
            </button>
          </div>
        </div>

        <div className="space-y-6">
           <div className="bg-gradient-to-br from-orange-500 to-amber-600 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 w-32 h-32 bg-white/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700" />
              <h4 className="text-white font-black text-xl mb-4">Elite Coaching</h4>
              <p className="text-white/80 text-sm font-medium leading-relaxed mb-6">Access professional dermatologists and stylists for direct routine audits.</p>
              <button className="w-full bg-white text-orange-600 font-black py-3 rounded-2xl hover:bg-slate-50 transition-all active:scale-95 shadow-lg shadow-black/10 uppercase text-xs tracking-widest">Upgrade to Elite</button>
           </div>

           <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-md">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                <CalendarIcon className="w-3 h-3 text-orange-600" />
                Consistency View
              </h4>
              <div className="grid grid-cols-7 gap-1">
                 {Array.from({ length: 31 }).map((_, i) => (
                    <div key={i} className={`aspect-square rounded-[4px] border border-slate-100 ${i < 12 ? 'bg-orange-500' : i === 12 ? 'bg-orange-600 ring-2 ring-orange-200' : 'bg-slate-50'}`} />
                 ))}
              </div>
              <p className="text-[9px] text-slate-500 mt-3 font-black uppercase tracking-widest">Current Streak: {streak} days</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Routines;