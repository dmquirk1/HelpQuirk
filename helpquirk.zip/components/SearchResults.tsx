import React from 'react';
import { MOCK_POSTS, MOCK_GIGS, MOCK_PROFILES } from '../constants';
import { Users, Briefcase, Image as ImageIcon, ArrowRight } from 'lucide-react';

interface SearchResultsProps {
  query: string;
  onNavigate: (tab: any) => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({ query, onNavigate }) => {
  const normalizedQuery = query.toLowerCase();

  const filteredPosts = MOCK_POSTS.filter(
    p => p.description.toLowerCase().includes(normalizedQuery) || p.user.toLowerCase().includes(normalizedQuery)
  );
  
  const filteredGigs = MOCK_GIGS.filter(
    g => g.title.toLowerCase().includes(normalizedQuery) || g.description.toLowerCase().includes(normalizedQuery)
  );
  
  const filteredProfiles = MOCK_PROFILES.filter(
    p => p.name.toLowerCase().includes(normalizedQuery) || p.handle.toLowerCase().includes(normalizedQuery) || p.bio.toLowerCase().includes(normalizedQuery)
  );

  const isEmpty = filteredPosts.length === 0 && filteredGigs.length === 0 && filteredProfiles.length === 0;

  if (isEmpty) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <Users className="w-16 h-16 mb-4 opacity-10" />
        <p className="text-lg font-black text-slate-900">No results found for "{query}"</p>
        <p className="text-sm font-medium">Try different keywords or professional categories.</p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-10 px-4 space-y-12 animate-in fade-in duration-300">
      <div className="border-b border-slate-200 pb-4">
        <h2 className="text-2xl font-black text-slate-900">Search results for "{query}"</h2>
      </div>

      {/* Profiles */}
      {filteredProfiles.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest">
            <Users className="w-4 h-4 text-orange-600" />
            Verified Profiles
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProfiles.map(profile => (
              <div key={profile.id} className="bg-white border border-slate-200 p-4 rounded-2xl flex items-center gap-4 hover:border-orange-500 transition-colors group cursor-pointer shadow-sm">
                <img src={profile.avatar} alt={profile.name} className="w-12 h-12 rounded-full border border-slate-100" />
                <div className="flex-1 min-w-0">
                  <h4 className="font-black truncate text-slate-900 text-sm">{profile.name}</h4>
                  <p className="text-[10px] font-bold text-slate-400 truncate uppercase tracking-tighter">{profile.handle}</p>
                </div>
                <button className="p-2 rounded-lg bg-slate-50 group-hover:bg-orange-600 group-hover:text-white transition-colors">
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Posts */}
      {filteredPosts.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest">
            <ImageIcon className="w-4 h-4 text-orange-600" />
            Product Concepts
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredPosts.map(post => (
              <div 
                key={post.id} 
                className="relative aspect-[3/4] bg-white rounded-2xl overflow-hidden group cursor-pointer shadow-md"
                onClick={() => onNavigate('FEED')}
              >
                <img src={post.videoUrl} alt="post" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent p-4 flex flex-col justify-end">
                  <p className="text-[10px] text-white line-clamp-1 opacity-0 group-hover:opacity-100 transition-opacity font-medium">{post.description}</p>
                  <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest">@{post.user}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Gigs */}
      {filteredGigs.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest">
            <Briefcase className="w-4 h-4 text-orange-600" />
            Marketplace Gigs
          </div>
          <div className="space-y-3">
            {filteredGigs.map(gig => (
              <div 
                key={gig.id} 
                className="bg-white border border-slate-200 p-5 rounded-2xl flex items-center justify-between hover:border-orange-500 transition-all cursor-pointer shadow-sm"
                onClick={() => onNavigate('BUSINESS')}
              >
                <div className="flex-1 pr-4">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[8px] font-black uppercase tracking-widest bg-orange-600/10 text-orange-600 px-2 py-0.5 rounded border border-orange-200">
                      {gig.type}
                    </span>
                    <h4 className="font-black text-slate-900">{gig.title}</h4>
                  </div>
                  <p className="text-xs text-slate-500 font-medium line-clamp-1">{gig.description}</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-black text-emerald-600">{gig.earnings}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default SearchResults;