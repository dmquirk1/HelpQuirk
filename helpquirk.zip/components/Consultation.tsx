
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, Video, VideoOff, PhoneOff, Info, Sparkles } from 'lucide-react';
import { GoogleGenAI, Modality } from '@google/genai';

const Consultation: React.FC = () => {
  const [isCalling, setIsCalling] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: true 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCalling(true);
      setError(null);
    } catch (err) {
      console.error(err);
      setError("Please allow camera and microphone access to start the AI consultation.");
    }
  };

  const endCall = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
    setIsCalling(false);
  };

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 h-[calc(100vh-160px)] flex flex-col">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">HelpQuirk Live Stylist</h2>
          <p className="text-slate-400 text-sm">Real-time voice & video looksmaxxing advisor.</p>
        </div>
        <div className="bg-violet-500/10 border border-violet-500/20 p-3 rounded-lg flex items-center gap-2 max-w-sm">
          <Info className="w-4 h-4 text-violet-400 shrink-0" />
          <p className="text-[10px] text-violet-300">This feature uses Gemini 2.5 Flash for ultra-low latency styling advice. Your privacy is protected.</p>
        </div>
      </div>

      <div className="flex-1 bg-slate-900 rounded-3xl overflow-hidden relative shadow-2xl border border-slate-700">
        {!isCalling ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center space-y-6">
            <div className="relative">
              <div className="w-32 h-32 bg-violet-600 rounded-full flex items-center justify-center animate-pulse">
                <Mic className="w-12 h-12 text-white" />
              </div>
              <div className="absolute -inset-4 border-2 border-violet-500/30 rounded-full animate-ping" />
            </div>
            <div className="text-center">
              <h3 className="text-xl font-bold">Ready to consult?</h3>
              <p className="text-slate-400 mt-1">Talk about your hair, skin, or today's outfit.</p>
            </div>
            <button 
              onClick={startStream}
              className="bg-violet-600 hover:bg-violet-500 px-8 py-3 rounded-full font-bold transition-transform hover:scale-105"
            >
              Start Session
            </button>
            {error && <p className="text-red-400 text-sm max-w-xs text-center">{error}</p>}
          </div>
        ) : (
          <div className="h-full flex flex-col">
            <div className="flex-1 relative">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted={!isMicOn}
                className={`w-full h-full object-cover transition-opacity ${isVideoOn ? 'opacity-100' : 'opacity-0'}`}
              />
              {!isVideoOn && (
                <div className="absolute inset-0 bg-slate-800 flex items-center justify-center">
                  <VideoOff className="w-16 h-16 text-slate-600" />
                </div>
              )}
              
              <div className="absolute top-4 right-4 w-48 aspect-video bg-black rounded-xl border-2 border-white/10 overflow-hidden">
                <div className="w-full h-full bg-slate-800 flex items-center justify-center text-xs text-slate-500">
                  <div className="flex flex-col items-center">
                    {/* Fixed: Added Sparkles to imports above */}
                    <Sparkles className="w-6 h-6 mb-1 text-violet-400" />
                    AI Vision Active
                  </div>
                </div>
              </div>

              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/40 backdrop-blur-xl p-4 rounded-full border border-white/10">
                <button 
                  onClick={() => setIsMicOn(!isMicOn)}
                  className={`p-4 rounded-full transition-colors ${isMicOn ? 'bg-slate-700 hover:bg-slate-600' : 'bg-red-500 hover:bg-red-400'}`}
                >
                  {isMicOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
                </button>
                <button 
                  onClick={() => setIsVideoOn(!isVideoOn)}
                  className={`p-4 rounded-full transition-colors ${isVideoOn ? 'bg-slate-700 hover:bg-slate-600' : 'bg-red-500 hover:bg-red-400'}`}
                >
                  {isVideoOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
                </button>
                <button 
                  onClick={endCall}
                  className="p-4 rounded-full bg-red-600 hover:bg-red-500 transition-colors"
                >
                  <PhoneOff className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="h-24 bg-black/20 border-t border-slate-700 flex items-center px-8">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <p className="text-slate-300 text-sm font-medium">Listening for your styling questions...</p>
              </div>
              <div className="flex-1" />
              <canvas ref={canvasRef} className="hidden" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Consultation;
