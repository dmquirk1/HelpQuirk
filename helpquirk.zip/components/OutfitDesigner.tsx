import React, { useState, useRef } from 'react';
import { Sparkles, Loader2, RefreshCcw, Shirt, Dna, Palette, Check, Heart, Brain, Zap, Moon, Upload, X, User, Tag, Briefcase, Wand2 } from 'lucide-react';
import { generateOutfit, analyzeColorDNA } from '../services/gemini';

const MOODS = [
  { id: 'powerful', label: 'Powerful', icon: Zap, color: 'text-orange-600', prompt: 'boss, high contrast, strong silhouettes' },
  { id: 'relaxed', label: 'Relaxed', icon: Moon, color: 'text-blue-500', prompt: 'comfortable, loose fit, earthy tones' },
  { id: 'romantic', label: 'Romantic', icon: Heart, color: 'text-rose-500', prompt: 'soft fabrics, pastel, elegant' },
  { id: 'creative', label: 'Creative', icon: Brain, color: 'text-amber-500', prompt: 'eclectic, patterns, unique textures' }
];

const STYLE_CHIPS = [
  'Monochrome', 'Oversized', 'Linen', 'Layered', 'Vintage', 'Cyberpunk', 'Quiet Luxury', 'Y2K', 'Techwear'
];

const OCCASIONS = [
  'Business Meeting', 'Summer Wedding', 'First Date', 'Airport Look', 'Gym Session', 'Night Out'
];

const OutfitDesigner: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedOccasion, setSelectedOccasion] = useState<string | null>(null);
  const [selectedChips, setSelectedChips] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [dnaLoading, setDnaLoading] = useState(false);
  const [dnaResult, setDnaResult] = useState<any>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearUploadedImage = () => {
    setUploadedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const toggleChip = (chip: string) => {
    setSelectedChips(prev => 
      prev.includes(chip) ? prev.filter(c => c !== chip) : [...prev, chip]
    );
  };

  const handleGenerate = async () => {
    let finalPromptParts = [prompt];
    
    if (selectedMood) {
      const moodData = MOODS.find(m => m.id === selectedMood);
      finalPromptParts.push(`Mood: ${moodData?.label}. ${moodData?.prompt}`);
    }

    if (selectedOccasion) {
      finalPromptParts.push(`Occasion: ${selectedOccasion}`);
    }

    if (selectedChips.length > 0) {
      finalPromptParts.push(`Style details: ${selectedChips.join(', ')}`);
    }

    const finalPrompt = finalPromptParts.filter(p => p.trim()).join('. ');
    
    if (!finalPrompt.trim() && !uploadedImage) return;
    
    setLoading(true);
    const result = await generateOutfit(finalPrompt || "A stylish outfit matching this person", uploadedImage || undefined);
    setImageUrl(result);
    setLoading(false);
  };

  const handleDnaAnalysis = async () => {
    if (!uploadedImage) {
      setDnaLoading(true);
      setTimeout(() => {
        setDnaResult({
          season: "Warm Autumn",
          palette: ["#f97316", "#D2691E", "#556B2F", "#DAA520", "#B45309"],
          hairTip: "Golden honey highlights would enhance your professional warmth.",
          makeupAdvice: "Opt for warm peach blushes and terra-cotta tones."
        });
        setDnaLoading(false);
      }, 2000);
      return;
    }

    setDnaLoading(true);
    const result = await analyzeColorDNA(uploadedImage);
    if (result) {
      setDnaResult(result);
    }
    setDnaLoading(false);
  };

  return (
    <div className="max-w-6xl mx-auto py-10 px-4 space-y-12">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black mb-2 flex items-center gap-3 text-slate-900">
            <Shirt className="text-orange-600 w-10 h-10" />
            Style Lab
          </h2>
          <p className="text-slate-500 font-medium">Personalized AI styling & outfit visualization.</p>
        </div>
        
        <button 
          onClick={handleDnaAnalysis}
          disabled={dnaLoading}
          className="group relative flex items-center gap-3 bg-white hover:bg-slate-50 border border-orange-500/30 p-4 rounded-2xl transition-all overflow-hidden disabled:opacity-50 shadow-sm"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="bg-orange-600/10 p-2 rounded-xl group-hover:scale-110 transition-transform">
            {dnaLoading ? <Loader2 className="w-6 h-6 text-orange-600 animate-spin" /> : <Dna className="text-orange-600 w-6 h-6" />}
          </div>
          <div className="text-left">
            <p className="text-xs font-bold text-orange-600 uppercase tracking-widest">DNA Analysis</p>
            <p className="font-bold text-slate-800">{uploadedImage ? 'Analyze My Colors' : 'AI Color DNA Demo'}</p>
          </div>
        </button>
      </div>

      {dnaResult && (
        <div className="bg-white border border-orange-500/20 rounded-[2.5rem] p-8 animate-in zoom-in duration-500 shadow-xl shadow-orange-500/5">
          <div className="flex flex-col md:flex-row gap-10">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-4">
                <Palette className="w-5 h-5 text-orange-600" />
                <h3 className="text-xl font-bold text-slate-900">Your Season: <span className="text-orange-600">{dnaResult.season}</span></h3>
              </div>
              <p className="text-slate-600 text-sm mb-6 leading-relaxed font-medium">
                {dnaResult.hairTip}
              </p>
              <div className="flex gap-3">
                {dnaResult.palette.map((color: string) => (
                  <div key={color} className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-2xl shadow-md border border-slate-100" style={{ backgroundColor: color }} />
                    <span className="text-[8px] font-mono text-slate-400 font-bold">{color}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex-1 bg-slate-50 rounded-3xl p-6 border border-slate-200">
               <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">AI Recommendations</h4>
               <ul className="space-y-3">
                 <li className="flex items-start gap-3 text-sm text-slate-700 font-medium">
                   <div className="w-5 h-5 bg-orange-600/10 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                     <Check className="w-3 h-3 text-orange-600" />
                   </div>
                   {dnaResult.makeupAdvice}
                 </li>
                 <li className="flex items-start gap-3 text-sm text-slate-700 font-medium">
                   <div className="w-5 h-5 bg-orange-600/10 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                     <Check className="w-3 h-3 text-orange-600" />
                   </div>
                   Focus on {dnaResult.season} tones for maximum professional impact.
                 </li>
               </ul>
            </div>
          </div>
        </div>
      )}

      {/* Main Designer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Visual Inputs */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-lg space-y-4">
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <User className="w-4 h-4" />
              Base Photo
            </label>
            
            <div 
              onClick={() => !uploadedImage && fileInputRef.current?.click()}
              className={`relative aspect-[3/4] rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center cursor-pointer overflow-hidden ${
                uploadedImage ? 'border-orange-500/50' : 'border-slate-200 hover:border-orange-300 bg-slate-50'
              }`}
            >
              {uploadedImage ? (
                <>
                  <img src={uploadedImage} alt="Uploaded base" className="w-full h-full object-cover" />
                  <button 
                    onClick={(e) => { e.stopPropagation(); clearUploadedImage(); }}
                    className="absolute top-2 right-2 p-1.5 bg-black/60 backdrop-blur-md rounded-full text-white hover:bg-red-500 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <div className="text-center p-6 space-y-3">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm">
                    <Upload className="w-6 h-6 text-slate-400" />
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1 uppercase font-black tracking-widest">Upload Selfie</p>
                </div>
              )}
              <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-lg space-y-4">
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Vibe
            </label>
            <div className="grid grid-cols-2 gap-2">
              {MOODS.map(mood => (
                <button
                  key={mood.id}
                  onClick={() => setSelectedMood(selectedMood === mood.id ? null : mood.id)}
                  className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 font-bold ${
                    selectedMood === mood.id 
                    ? 'bg-orange-600 border-orange-500 text-white shadow-lg' 
                    : 'bg-slate-50 border-slate-100 text-slate-500 hover:border-orange-200'
                  }`}
                >
                  <mood.icon className={`w-4 h-4 ${selectedMood === mood.id ? 'text-white' : mood.color}`} />
                  <span className="text-[10px] uppercase tracking-tighter">{mood.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Center Column: Textual Inputs & Custom Prompting */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-lg h-full flex flex-col space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-black text-slate-400 uppercase tracking-widest">Custom Prompt</label>
                <button className="text-[10px] font-black text-orange-600 hover:text-orange-500 transition-colors flex items-center gap-1 uppercase tracking-widest">
                  <Wand2 className="w-3 h-3" />
                  AI Refine
                </button>
              </div>
              <textarea
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-5 text-slate-900 focus:ring-2 focus:ring-orange-500 outline-none resize-none transition-all placeholder:text-slate-400 min-h-[120px] font-medium"
                placeholder={uploadedImage ? "How should we style this photo?" : "Describe your dream outfit..."}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Briefcase className="w-3 h-3" />
                Occasion
              </label>
              <div className="flex flex-wrap gap-2">
                {OCCASIONS.map(occ => (
                  <button
                    key={occ}
                    onClick={() => setSelectedOccasion(selectedOccasion === occ ? null : occ)}
                    className={`px-3 py-1.5 rounded-full text-[10px] font-bold transition-all border ${
                      selectedOccasion === occ 
                      ? 'bg-orange-600 border-orange-500 text-white shadow-sm' 
                      : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-orange-600 hover:bg-orange-50'
                    }`}
                  >
                    {occ}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Tag className="w-3 h-3" />
                Aesthetic Details
              </label>
              <div className="flex flex-wrap gap-2">
                {STYLE_CHIPS.map(chip => (
                  <button
                    key={chip}
                    onClick={() => toggleChip(chip)}
                    className={`px-3 py-1.5 rounded-full text-[10px] font-bold transition-all border ${
                      selectedChips.includes(chip)
                      ? 'bg-amber-500 border-amber-400 text-white shadow-sm' 
                      : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-amber-600 hover:bg-amber-50'
                    }`}
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={loading || (!prompt.trim() && !uploadedImage && !selectedMood && !selectedOccasion)}
              className="w-full mt-auto bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 transition-all active:scale-95 shadow-xl shadow-orange-600/20 uppercase tracking-widest"
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Sparkles className="w-6 h-6" />}
              {loading ? 'VISUALIZING...' : 'GENERATE LOOK'}
            </button>
          </div>
        </div>

        {/* Right Column: Visualization Output */}
        <div className="lg:col-span-4">
          <div className="bg-white aspect-[3/4] rounded-[2rem] border-2 border-dashed border-slate-200 flex flex-col items-center justify-center relative overflow-hidden shadow-xl group">
            {imageUrl ? (
              <>
                <img src={imageUrl} alt="Generated Outfit" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                   <button onClick={() => setImageUrl(null)} className="bg-white p-4 rounded-full hover:bg-orange-50 transition-all shadow-xl">
                    <RefreshCcw className="w-6 h-6 text-orange-600" />
                   </button>
                </div>
              </>
            ) : (
              <div className="text-center p-8 space-y-4">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto ring-8 ring-slate-100">
                  <Shirt className="w-10 h-10 text-slate-300" />
                </div>
                <div>
                  <p className="text-slate-800 font-black text-lg">Empty Runway</p>
                  <p className="text-slate-500 text-sm mt-1 font-medium">AI visualization will appear here.</p>
                </div>
              </div>
            )}
            {loading && (
              <div className="absolute inset-0 bg-white/90 backdrop-blur-xl flex items-center justify-center z-20">
                <div className="text-center">
                  <div className="relative w-20 h-20 mx-auto mb-6">
                    <div className="absolute inset-0 border-4 border-orange-500/10 rounded-full" />
                    <div className="absolute inset-0 border-4 border-t-orange-600 rounded-full animate-spin" />
                  </div>
                  <p className="text-lg font-black text-slate-900 tracking-widest animate-pulse uppercase">Tailoring design...</p>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default OutfitDesigner;