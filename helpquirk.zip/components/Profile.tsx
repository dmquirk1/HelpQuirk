
import React, { useState } from 'react';
/* Added missing Loader2 import from lucide-react */
import { Camera, Save, User, Hash, Sparkles, Check, UserPlus, UserMinus, Users, Loader2 } from 'lucide-react';

const STYLE_OPTIONS = [
  'Streetwear', 'Formal', 'Minimalist', 'Bohemian', 
  'Gorpcore', 'Vintage', 'Cyberpunk', 'Academic'
];

const Profile: React.FC = () => {
  const [profile, setProfile] = useState({
    name: 'Alex Style',
    bio: 'Professional fashion enthusiast and digital boutique curator. Focused on minimalist aesthetics.',
    avatar: 'https://picsum.photos/seed/alex/200/200',
    preferredStyles: ['Minimalist', 'Streetwear'],
    followers: 1240,
    following: 382
  });

  const [isSaving, setIsSaving] = useState(false);
  const [showSavedMsg, setShowSavedMsg] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  const toggleStyle = (style: string) => {
    setProfile(prev => ({
      ...prev,
      preferredStyles: prev.preferredStyles.includes(style)
        ? prev.preferredStyles.filter(s => s !== style)
        : [...prev.preferredStyles, style]
    }));
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setShowSavedMsg(true);
      setTimeout(() => setShowSavedMsg(false), 3000);
    }, 1000);
  };

  const toggleFollow = () => {
    setIsFollowing(!isFollowing);
    setProfile(prev => ({
      ...prev,
      followers: isFollowing ? prev.followers - 1 : prev.followers + 1
    }));
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 animate-in fade-in duration-500">
      <div className="mb-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Personal Identity</h2>
          <p className="text-slate-500 font-medium">Manage your professional presence and style DNA.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={toggleFollow}
            className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl font-black uppercase text-xs tracking-widest transition-all active:scale-95 border-2 ${
              isFollowing 
                ? 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50' 
                : 'bg-orange-600 border-orange-600 text-white hover:bg-orange-500 shadow-lg shadow-orange-600/20'
            }`}
          >
            {isFollowing ? (
              <>
                <UserMinus className="w-4 h-4 mr-2" />
                Unfollow
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4 mr-2" />
                Follow
              </>
            )}
          </button>
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex-1 sm:flex-none bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white px-6 py-2.5 rounded-xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md"
          >
            {/* Fixed missing Loader2 component */}
            {isSaving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {isSaving ? 'Updating...' : 'Save DNA'}
          </button>
        </div>
      </div>

      {showSavedMsg && (
        <div className="mb-6 bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-center gap-3 text-emerald-600 animate-in slide-in-from-top-2 shadow-sm font-bold text-sm">
          <Check className="w-5 h-5" />
          Protocol Updated
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-6">
          <div className="bg-white rounded-[2.5rem] p-6 border border-slate-200 flex flex-col items-center shadow-lg">
            <div className="relative group cursor-pointer ring-8 ring-slate-50 rounded-full">
              <img 
                src={profile.avatar} 
                alt="Profile" 
                className="w-32 h-32 rounded-full border-4 border-white object-cover group-hover:opacity-75 transition-opacity" 
              />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-8 h-8 text-white drop-shadow-md" />
              </div>
              <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" />
            </div>
            <h3 className="mt-6 font-black text-lg text-slate-900">{profile.name}</h3>
            <p className="text-[10px] font-black uppercase tracking-widest mt-1 bg-slate-100 text-slate-500 px-3 py-1 rounded-full border border-slate-200">Standard Member</p>
          </div>

          <div className="bg-white rounded-[2.5rem] p-6 border border-slate-200 shadow-lg">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-orange-600" />
              Creator Analytics
            </h4>
            <div className="grid grid-cols-2 gap-4 mb-6">
               <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                  <p className="text-xl font-black text-slate-900">{profile.followers.toLocaleString()}</p>
                  <p className="text-[10px] text-slate-400 uppercase font-black mt-1 tracking-tighter">Followers</p>
               </div>
               <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                  <p className="text-xl font-black text-slate-900">{profile.following.toLocaleString()}</p>
                  <p className="text-[10px] text-slate-400 uppercase font-black mt-1 tracking-tighter">Following</p>
               </div>
            </div>
            <div className="space-y-4 border-t border-slate-100 pt-6">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-slate-400 uppercase tracking-widest">Network Status</span>
                <span className="text-emerald-600">Active</span>
              </div>
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-slate-400 uppercase tracking-widest">Post Index</span>
                <span className="text-slate-900">42</span>
              </div>
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-slate-400 uppercase tracking-widest">Style Tier</span>
                <span className="text-orange-600 uppercase">Platinum</span>
              </div>
            </div>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-200 shadow-lg space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <User className="w-4 h-4 text-orange-600" />
                Verified Name
              </label>
              <input 
                type="text" 
                value={profile.name}
                onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-orange-500 outline-none transition-all text-slate-900 placeholder:text-slate-400 font-bold"
                placeholder="Name"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Professional Bio</label>
              <textarea 
                rows={4}
                value={profile.bio}
                onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 focus:ring-2 focus:ring-orange-500 outline-none transition-all resize-none text-slate-900 placeholder:text-slate-400 font-medium"
                placeholder="Share your philosophy..."
              />
            </div>

            <div className="space-y-4 pt-6 border-t border-slate-100">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Hash className="w-4 h-4 text-orange-600" />
                Specializations
              </label>
              <div className="flex flex-wrap gap-2">
                {STYLE_OPTIONS.map(style => {
                  const isActive = profile.preferredStyles.includes(style);
                  return (
                    <button
                      key={style}
                      onClick={() => toggleStyle(style)}
                      className={`px-4 py-2 rounded-full text-[10px] font-black transition-all uppercase tracking-widest ${
                        isActive 
                        ? 'bg-orange-600 text-white shadow-md border border-orange-500' 
                        : 'bg-slate-50 text-slate-400 hover:text-slate-900 border border-slate-200'
                      }`}
                    >
                      {isActive && <Check className="w-3 h-3 inline mr-1.5" />}
                      {style}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
