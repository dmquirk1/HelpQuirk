import React from 'react';
import { Crown, Check, ShieldCheck, Zap, ShoppingBag, TrendingUp, Percent } from 'lucide-react';

const Membership: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto py-16 px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-black mb-4 text-slate-900 uppercase tracking-tight">Professional Ecosystem</h2>
        <p className="text-slate-500 text-lg font-medium max-w-2xl mx-auto">Scale your influence as a Creator, Enthusiast, or Merchant Partner.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Free Tier */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 flex flex-col shadow-sm">
          <h3 className="text-xl font-black mb-2 text-slate-900">Standard</h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Foundational tools for your look.</p>
          <div className="text-4xl font-black mb-8 text-slate-900">$0<span className="text-lg text-slate-400 font-bold tracking-widest">/mo</span></div>
          <ul className="space-y-4 mb-8 flex-1">
            <li className="flex items-center gap-3 text-sm text-slate-600 font-bold">
              <Check className="w-4 h-4 text-orange-500" />
              Style Feed Access
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-600 font-bold">
              <Check className="w-4 h-4 text-orange-500" />
              Basic Routine Builder
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-600 font-bold">
              <Check className="w-4 h-4 text-orange-500" />
              3% Affiliate Rewards
            </li>
          </ul>
          <button className="w-full py-3 border border-slate-200 text-slate-400 rounded-xl font-black uppercase text-xs tracking-widest">Active Plan</button>
        </div>

        {/* Pro / Merchant Tier */}
        <div className="bg-white p-8 rounded-3xl border-2 border-orange-600 relative flex flex-col shadow-2xl shadow-orange-600/10">
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-orange-600 text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-md">Popular: Merchant</div>
          <h3 className="text-xl font-black mb-2 flex items-center gap-2 text-slate-900">
            Professional Partner
            <ShoppingBag className="w-4 h-4 text-orange-600" />
          </h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Full commerce integration.</p>
          <div className="text-4xl font-black mb-8 text-orange-600">$29<span className="text-lg text-slate-400 font-bold tracking-widest">/mo</span></div>
          <ul className="space-y-4 mb-8 flex-1">
            <li className="flex items-center gap-3 text-sm text-slate-700 font-black">
              <Check className="w-4 h-4 text-orange-500" />
              Verified Seller Status
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-700 font-black">
              <Percent className="w-4 h-4 text-orange-500" />
              Fixed 8% Commissions
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-700 font-black">
              <TrendingUp className="w-4 h-4 text-orange-500" />
              Shop Window on Feed
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-700 font-black">
              <ShieldCheck className="w-4 h-4 text-orange-500" />
              Secure Payout Handling
            </li>
          </ul>
          <button className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-white rounded-xl font-black uppercase text-xs tracking-widest transition-all shadow-lg shadow-orange-600/20 active:scale-95">Enroll Boutique</button>
        </div>

        {/* Elite Tier */}
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 flex flex-col shadow-xl">
          <h3 className="text-xl font-black mb-2 flex items-center gap-2 text-white">
            Elite Creator
            <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
          </h3>
          <p className="text-slate-400 text-sm font-medium mb-6">Scale without limits.</p>
          <div className="text-4xl font-black mb-8 text-white">$49<span className="text-lg text-slate-500 font-bold tracking-widest">/mo</span></div>
          <ul className="space-y-4 mb-8 flex-1">
            <li className="flex items-center gap-3 text-sm text-slate-300 font-bold">
              <Check className="w-4 h-4 text-orange-500" />
              Lower 5% Marketplace Fee
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-300 font-bold">
              <Check className="w-4 h-4 text-orange-500" />
              Priority AI Design Access
            </li>
            <li className="flex items-center gap-3 text-sm text-slate-300 font-bold">
              <Check className="w-4 h-4 text-orange-500" />
              Style DNA Professional Audit
            </li>
          </ul>
          <button className="w-full py-3 bg-white text-slate-900 rounded-xl font-black uppercase text-xs tracking-widest hover:bg-slate-100 transition-colors">Go Elite</button>
        </div>
      </div>

      <div className="mt-20 bg-white p-10 rounded-[40px] border border-slate-200 flex flex-col md:flex-row items-center gap-12 shadow-xl">
        <div className="flex-1 space-y-6">
          <div className="inline-flex items-center gap-2 bg-orange-600/10 text-orange-600 px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest">
            <ShieldCheck className="w-4 h-4" />
            Vetted Partner Program
          </div>
          <h3 className="text-3xl font-black leading-tight text-slate-900">Professional Business Launchpad</h3>
          <p className="text-slate-500 font-medium text-lg leading-relaxed">Join 500+ successful merchants who scale their personal brand on HelpQuirk. We handle the technology so you can focus on the aesthetic.</p>
          <div className="flex gap-4 pt-4">
             <div className="text-center bg-slate-50 p-6 rounded-3xl flex-1 border border-slate-100">
                <p className="text-3xl font-black text-slate-900">500+</p>
                <p className="text-[10px] text-slate-400 uppercase font-black mt-1 tracking-widest">Top Sellers</p>
             </div>
             <div className="text-center bg-slate-50 p-6 rounded-3xl flex-1 border border-slate-100">
                <p className="text-3xl font-black text-orange-600">8%</p>
                <p className="text-[10px] text-slate-400 uppercase font-black mt-1 tracking-widest">Marketplace Rate</p>
             </div>
          </div>
        </div>
        <div className="w-full md:w-1/3 aspect-square bg-gradient-to-tr from-orange-600 to-amber-500 rounded-[60px] shadow-2xl flex items-center justify-center rotate-3 border-8 border-white">
          <ShoppingBag className="w-32 h-32 text-white/50 animate-bounce" />
        </div>
      </div>
    </div>
  );
};

export default Membership;