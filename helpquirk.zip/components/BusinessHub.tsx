import React, { useState } from 'react';
import { 
  Briefcase, 
  TrendingUp, 
  Users, 
  ExternalLink, 
  ShoppingBag, 
  Tag, 
  Zap, 
  Timer, 
  Star,
  Compass,
  Loader2,
  CheckCircle2,
  ArrowRight,
  Handshake,
  Wand2,
  DollarSign,
  Sparkles
} from 'lucide-react';
import { MOCK_GIGS } from '../constants';
import { generateBusinessRoadmap } from '../services/gemini';

const BusinessHub: React.FC = () => {
  const [businessInput, setBusinessInput] = useState('');
  const [roadmap, setRoadmap] = useState<any | null>(null);
  const [loadingRoadmap, setLoadingRoadmap] = useState(false);

  const flashGigs = MOCK_GIGS.filter(g => g.isFlash);
  const regularGigs = MOCK_GIGS.filter(g => !g.isFlash);

  const handleBuildBusiness = async () => {
    if (!businessInput.trim()) return;
    setLoadingRoadmap(true);
    const result = await generateBusinessRoadmap(businessInput);
    setRoadmap(result);
    setLoadingRoadmap(false);
  };

  return (
    <div className="max-w-6xl mx-auto py-12 px-4 space-y-16">
      {/* Hero Section */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 bg-orange-600/10 text-orange-600 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest">
           <Zap className="w-4 h-4 fill-orange-600" />
           The Entrepreneur Lab
        </div>
        <h2 className="text-5xl font-black text-slate-900 tracking-tight leading-none">Scale your personal brand.</h2>
        <p className="text-slate-500 text-lg font-medium">Start a boutique agency or earn by helping others build theirs.</p>
      </div>

      {/* Revenue Snapshot */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 p-8 rounded-[2.5rem] shadow-sm flex flex-col justify-between">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Net Earnings</p>
           <div className="flex items-end justify-between">
              <h3 className="text-4xl font-black text-slate-900">$1,240</h3>
              <div className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">+12% this week</div>
           </div>
        </div>
        <div className="bg-white border border-slate-200 p-8 rounded-[2.5rem] shadow-sm flex flex-col justify-between">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Active Gig Contracts</p>
           <div className="flex items-end justify-between">
              <h3 className="text-4xl font-black text-slate-900">3</h3>
              <div className="bg-orange-50 text-orange-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">1 New Invite</div>
           </div>
        </div>
        <div className="bg-orange-600 p-8 rounded-[2.5rem] shadow-2xl shadow-orange-600/20 flex flex-col justify-between text-white">
           <p className="text-[10px] font-black text-white/60 uppercase tracking-widest mb-4">Elite Marketplace Tier</p>
           <div className="flex items-end justify-between">
              <h3 className="text-4xl font-black">Level 4</h3>
              <button className="bg-white text-orange-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg">View Perks</button>
           </div>
        </div>
      </div>

      {/* AI Business Launchpad */}
      <section className="bg-slate-900 rounded-[3rem] p-12 border border-slate-800 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none group-hover:opacity-10 transition-opacity">
          <Compass className="w-64 h-64 text-orange-500 animate-spin-slow" />
        </div>
        
        <div className="max-w-2xl relative z-10 space-y-10">
          <div>
            <div className="inline-flex items-center gap-3 bg-white/5 text-orange-400 px-5 py-2 rounded-full text-[11px] font-black uppercase tracking-widest mb-6 border border-white/10">
              <Sparkles className="w-4 h-4" />
              AI Launch Architect
            </div>
            <h2 className="text-5xl font-black text-white leading-tight">What business are we building today?</h2>
            <p className="text-slate-400 text-xl font-medium mt-4">Draft a professional roadmap for your new Event Planning or Styling empire.</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <input 
              type="text" 
              placeholder="e.g. 'Wedding Event Agency', 'Personal Styling Hub'..." 
              value={businessInput}
              onChange={(e) => setBusinessInput(e.target.value)}
              className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-8 py-5 text-white font-medium focus:ring-2 focus:ring-orange-500 outline-none transition-all placeholder:text-slate-600"
            />
            <button 
              onClick={handleBuildBusiness}
              disabled={loadingRoadmap || !businessInput}
              className="bg-orange-600 hover:bg-orange-500 text-white font-black px-12 py-5 rounded-2xl transition-all shadow-2xl shadow-orange-600/20 flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 uppercase text-xs tracking-widest"
            >
              {loadingRoadmap ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
              {loadingRoadmap ? 'Architecting...' : 'Generate Blueprint'}
            </button>
          </div>

          {roadmap && (
            <div className="mt-16 space-y-10 animate-in slide-in-from-bottom-6 duration-700">
              <div className="p-10 bg-white/5 border border-white/10 rounded-[2.5rem] shadow-inner">
                <div className="flex items-center gap-4 mb-10">
                   <div className="w-12 h-12 bg-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                      <CheckCircle2 className="w-6 h-6 text-white" />
                   </div>
                   <h3 className="text-3xl font-black text-white tracking-tight">
                     Blueprint: <span className="text-orange-500">{roadmap.businessName}</span>
                   </h3>
                </div>
                
                <div className="space-y-8">
                  {roadmap.steps.map((step: any, i: number) => (
                    <div key={i} className="flex gap-6 group">
                      <div className="flex flex-col items-center">
                        <div className="w-10 h-10 bg-slate-800 text-orange-500 border border-white/10 rounded-full flex items-center justify-center font-black text-sm shrink-0 group-hover:bg-orange-600 group-hover:text-white transition-all duration-300">
                          {i + 1}
                        </div>
                        {i < 4 && <div className="w-px h-full bg-white/10 mt-2" />}
                      </div>
                      <div className="pb-8">
                        <h4 className="text-xl font-black text-white group-hover:text-orange-500 transition-colors">{step.title}</h4>
                        <p className="text-slate-400 text-base mt-2 leading-relaxed font-medium">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-orange-600/10 p-10 rounded-[2.5rem] border border-orange-500/20 flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="flex-1 space-y-4">
                  <h4 className="text-orange-500 font-black text-xs uppercase tracking-widest flex items-center gap-2">
                    <Handshake className="w-5 h-5" />
                    Hire Your Team
                  </h4>
                  <p className="text-white font-medium text-lg">We've identified 3 essential HelpQuirk roles to launch this plan successfully.</p>
                  <div className="flex flex-wrap gap-3">
                     {roadmap.skillsToHire.map((skill: string) => (
                       <span key={skill} className="bg-slate-900 text-orange-500 px-5 py-2.5 rounded-xl text-xs font-black border border-white/10 uppercase tracking-tighter">
                         {skill}
                       </span>
                     ))}
                  </div>
                </div>
                <button className="bg-white text-slate-900 px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-100 transition-all shadow-xl whitespace-nowrap">
                   Hire Helpers Now
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Helper Marketplace */}
      <section className="space-y-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">The Helper Marketplace</h2>
            <p className="text-slate-500 text-lg font-medium mt-2">Earn by lending your specific expertise to new agencies.</p>
          </div>
          <button className="bg-slate-900 text-white px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 shadow-xl transition-all">List Your Service</button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: 'Sarah J.', skill: 'Visual Merchandiser', rate: '$45/hr', rating: 4.9, avatar: 'https://picsum.photos/seed/sarah/100/100', tags: ['Retail', 'Visuals'] },
            { name: 'Mike D.', skill: 'Style Consultant', rate: '$65/hr', rating: 4.8, avatar: 'https://picsum.photos/seed/mike/100/100', tags: ['Grooming', 'Fit'] },
            { name: 'Lena K.', skill: 'Event Coordinator', rate: '$40/hr', rating: 5.0, avatar: 'https://picsum.photos/seed/lena/100/100', tags: ['Planning', 'Admin'] },
          ].map((skill, idx) => (
            <div key={idx} className="bg-white border border-slate-200 p-8 rounded-[3rem] shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all group cursor-pointer border-b-8 border-b-transparent hover:border-b-orange-600">
              <div className="flex items-center gap-5 mb-8">
                <img src={skill.avatar} className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-100 group-hover:border-orange-500 transition-colors" alt={skill.name} />
                <div>
                  <h4 className="font-black text-xl text-slate-900">{skill.name}</h4>
                  <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1 rounded-full border border-slate-100 mt-1">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span className="text-[10px] font-black text-slate-600">{skill.rating} Community Score</span>
                  </div>
                </div>
              </div>
              <h5 className="font-black text-xl text-slate-900 mb-2">{skill.skill}</h5>
              <div className="flex gap-2 mb-6">
                 {skill.tags.map(t => <span key={t} className="text-[10px] font-bold text-slate-400">#{t}</span>)}
              </div>
              <div className="flex items-center justify-between mb-8">
                <p className="text-orange-600 font-black text-lg">{skill.rate}</p>
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              </div>
              <button className="w-full bg-slate-50 group-hover:bg-orange-600 group-hover:text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-inner">Book Expert</button>
            </div>
          ))}
        </div>
      </section>

      {/* Affiliate Engine */}
      <section className="bg-white border border-slate-200 rounded-[3rem] p-12 shadow-sm flex flex-col md:flex-row gap-12 items-center">
         <div className="w-full md:w-1/3 aspect-square bg-slate-50 rounded-[3rem] border border-slate-200 flex items-center justify-center p-10 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-tr from-orange-600/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <TrendingUp className="w-32 h-32 text-orange-600 transition-transform duration-700 group-hover:scale-110" />
         </div>
         <div className="flex-1 space-y-8">
            <div>
               <h3 className="text-3xl font-black text-slate-900 tracking-tight">Affiliate Working</h3>
               <p className="text-slate-500 text-lg font-medium mt-2">Earn passive income by recommending products curated by our AI Stylists.</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
               <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Referral Rate</p>
                  <p className="text-2xl font-black text-orange-600">15% <span className="text-xs text-slate-400 font-bold ml-1">CASHBACK</span></p>
               </div>
               <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Network Reach</p>
                  <p className="text-2xl font-black text-slate-900">2.4k <span className="text-xs text-slate-400 font-bold ml-1">CLICKS</span></p>
               </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
               <div className="flex-1 bg-white border border-slate-200 rounded-2xl px-6 py-4 flex items-center justify-between">
                  <span className="text-sm font-mono text-slate-400">hq.io/ref/alex_style</span>
                  <button className="text-orange-600 font-black text-xs uppercase tracking-widest">Copy</button>
               </div>
               <button className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl hover:bg-slate-800">Launch Portal</button>
            </div>
         </div>
      </section>
    </div>
  );
};

export default BusinessHub;