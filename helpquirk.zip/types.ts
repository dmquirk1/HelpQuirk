
export enum NavTab {
  FEED = 'FEED',
  STYLING = 'STYLING',
  ROUTINES = 'ROUTINES',
  LIVE = 'LIVE',
  BUSINESS = 'BUSINESS',
  MEMBERSHIP = 'MEMBERSHIP',
  PROFILE = 'PROFILE'
}

export interface Post {
  id: string;
  user: string;
  avatar: string;
  videoUrl: string;
  description: string;
  likes: number;
  comments: number;
}

export interface RoutineItem {
  id: string;
  title: string;
  time: string;
  category: 'Skin' | 'Body' | 'Hair';
  completed: boolean;
}

export interface BusinessGig {
  id: string;
  title: string;
  earnings: string;
  type: 'Skill' | 'Event' | 'Business';
  description: string;
}
