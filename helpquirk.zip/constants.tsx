import React from 'react';

export const COLORS = {
  primary: '#f97316', // Orange 500
  secondary: '#0f172a', // Slate 900
  accent: '#fbbf24', // Amber 400
  background: '#f8fafc', // Slate 50
  surface: '#ffffff', // White
};

export const MOCK_POSTS = [
  {
    id: '1',
    user: 'AlexStyle',
    avatar: 'https://picsum.photos/seed/alex/100/100',
    videoUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=400&h=700',
    description: 'Minimalist aesthetic for corporate event planners. First impressions matter! #eventplanner #style',
    likes: 1240,
    comments: 89,
    isBattleEntry: true,
    quirkScore: 92,
    isProduct: true,
    price: 89.99,
    isSeller: true,
    brand: 'Urban Minimalist',
    category: 'outfit'
  },
  {
    id: 'ai-1',
    user: 'HelpQuirk AI',
    avatar: 'https://picsum.photos/seed/hqai/100/100',
    videoUrl: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&q=80&w=400&h=700',
    description: '[AI CONCEPT] Neo-Punk Cyber Jacket. Vote to have this produced by our partners!',
    likes: 5600,
    comments: 420,
    isAIDesign: true,
    isBattleEntry: true,
    quirkScore: 98,
    category: 'outfit'
  },
  {
    id: '2',
    user: 'SkinCarePro',
    avatar: 'https://picsum.photos/seed/skincare/100/100',
    videoUrl: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=400&h=700',
    description: 'Glass skin routine for the big event day. Consistency is key! ✨',
    likes: 3500,
    comments: 245,
    isProduct: true,
    price: 34.50,
    isSeller: false,
    brand: 'GlowLabs',
    category: 'skincare'
  },
  {
    id: '5',
    user: 'GroomingGuru',
    avatar: 'https://picsum.photos/seed/hair/100/100',
    videoUrl: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=400&h=700',
    description: 'The "Flow" haircut tutorial for looksmaxxing. Frame your face right!',
    likes: 2100,
    comments: 112,
    category: 'skincare' // Using skincare as a general grooming category for now
  },
  {
    id: '4',
    user: 'BizCoach',
    avatar: 'https://picsum.photos/seed/biz/100/100',
    videoUrl: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&q=80&w=400&h=700',
    description: 'How I started my Event Planning business with $0 and 2 HelpQuirk helpers.',
    likes: 1200,
    comments: 156,
    isProduct: false,
    category: 'business'
  }
];

export const MOCK_GIGS = [
  {
    id: 'g1',
    title: 'Personal Stylist Assistant',
    earnings: '$50/hr',
    type: 'Skill',
    description: 'Help clients pick outfits for major corporate events.',
    isFlash: false
  },
  {
    id: 'g2',
    title: 'Wedding Event Helper',
    earnings: '$35/hr',
    type: 'Event',
    description: 'On-site support for table styling and decor setup.',
    isFlash: false
  }
];

export const MOCK_PROFILES = [
  { id: 'p1', name: 'Alex Style', handle: '@alexstyle', avatar: 'https://picsum.photos/seed/alex/100/100', bio: 'Fashion enthusiast and digital creator.' },
  { id: 'p2', name: 'SkinCarePro', handle: '@skincarepro', avatar: 'https://picsum.photos/seed/skincare/100/100', bio: 'Expert dermatological consultant.' }
];